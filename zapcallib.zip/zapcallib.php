<?php

define('_ZAPCAL',1);

if(!defined('_ZAPCAL_BASE'))
{
	define('_ZAPCAL_BASE',__DIR__);
}

require_once(_ZAPCAL_BASE . '/includes/framework.php');

